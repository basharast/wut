<?php
$users = [];

//User = Key
$users["9F86D081884C7D659A2FEAA0C55AD015A3BF4F1B2B0B822CD15D6C15B0F00A08"] = "F6E0A1E2AC41945A9AA7FF8A8AAA0CEBC12A3BCC981A929AD5CF810A090E11AE";

if (isset($_POST["zKu"]) && isset($_POST["xRa"])) {
    $user = $_POST["zKu"];
    $key = $_POST["xRa"];

    if (array_key_exists($user, $users)) {
        if (strpos(strtoupper($users[$user]), $key) !== false) {
            echo "1";
            exit();
        }
    } else {
        if (array_key_exists(strtolower($user), $users)) {
            if (strpos(strtolower($users[$user]), strtolower($key)) !== false) {
                echo "1";
                exit();
            }
        }
    }
}
echo "0";
?>
