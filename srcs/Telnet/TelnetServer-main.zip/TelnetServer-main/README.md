<p align="center">
  <img src="assets/logo.png" width="176"><br>
  <b>C# Telnet server based on csharp-telnet by Doron Guttman</b><br>
  <a href="./src">Source</a> |
  <a href="https://github.com/doronguttman/csharp-telnet-server">Original</a> 
  <br><br>
  <img src="assets/screen.jpg"><br><br>
</p>


# Notice

- No authentication needed


# Credits

Developed by Doron Guttman

Enhanced by Bashar Astifan