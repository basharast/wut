﻿namespace TelnetServer.Comm
{
    public interface IData
    {
        byte[] GetBytes();
    }
}
